package com.example.myapplication.network

import com.example.myapplication.model.Student
import com.google.gson.annotations.SerializedName

/**
 * Data Transfer Object đại diện cho dữ liệu JSON sinh viên từ REST API.
 */
data class StudentDto(
    @SerializedName("id")
    val id: Int? = null,
    @SerializedName("full_name")
    val fullName: String,
    @SerializedName("student_code")
    val studentCode: String,
    @SerializedName("email")
    val email: String,
    @SerializedName("gpa")
    val gpa: Double,
    @SerializedName("major")
    val major: String? = null
)

fun StudentDto.toEntity(): Student {
    return Student(
        id = id ?: 0,
        fullName = fullName,
        studentCode = studentCode,
        email = email,
        gpa = gpa,
        major = major ?: "Công Nghệ Thông Tin"
    )
}
