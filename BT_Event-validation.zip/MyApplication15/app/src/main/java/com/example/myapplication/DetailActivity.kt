package com.example.myapplication

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.myapplication.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding

    companion object {
        const val EXTRA_FULL_NAME = "EXTRA_FULL_NAME"
        const val EXTRA_EMAIL = "EXTRA_EMAIL"
        const val EXTRA_PHONE = "EXTRA_PHONE"
        const val EXTRA_STUDENT_ID = "EXTRA_STUDENT_ID"
        const val EXTRA_CLASS_NAME = "EXTRA_CLASS_NAME"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(binding.scrollView) { _, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            binding.scrollView.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val fallback = getString(R.string.no_data)
        binding.tvFullName.text = intent.getStringExtra(EXTRA_FULL_NAME).takeUnless { it.isNullOrEmpty() } ?: fallback
        binding.tvEmail.text = intent.getStringExtra(EXTRA_EMAIL).takeUnless { it.isNullOrEmpty() } ?: fallback
        binding.tvPhone.text = intent.getStringExtra(EXTRA_PHONE).takeUnless { it.isNullOrEmpty() } ?: fallback
        binding.tvStudentId.text = intent.getStringExtra(EXTRA_STUDENT_ID).takeUnless { it.isNullOrEmpty() } ?: fallback
        binding.tvClassName.text = intent.getStringExtra(EXTRA_CLASS_NAME).takeUnless { it.isNullOrEmpty() } ?: fallback

        binding.btnBackToRegister.setOnClickListener { finish() }
    }
}