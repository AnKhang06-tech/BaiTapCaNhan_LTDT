package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.doOnTextChanged
import com.example.myapplication.databinding.ActivityMainBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(binding.scrollView) { _, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            binding.scrollView.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        listOf(
            binding.etFullName to binding.tilFullName,
            binding.etEmail to binding.tilEmail,
            binding.etPhone to binding.tilPhone,
            binding.etStudentId to binding.tilStudentId,
            binding.etClassName to binding.tilClassName,
        ).forEach { (et, til) -> et.doOnTextChanged { _, _, _, _ -> til.error = null } }

        binding.btnRegister.setOnClickListener {
            if (validateForm()) {
                val intent = Intent(this, DetailActivity::class.java).apply {
                    putExtra(DetailActivity.EXTRA_FULL_NAME, binding.etFullName.text?.toString()?.trim())
                    putExtra(DetailActivity.EXTRA_EMAIL, binding.etEmail.text?.toString()?.trim())
                    putExtra(DetailActivity.EXTRA_PHONE, binding.etPhone.text?.toString()?.trim())
                    putExtra(DetailActivity.EXTRA_STUDENT_ID, binding.etStudentId.text?.toString()?.trim())
                    putExtra(DetailActivity.EXTRA_CLASS_NAME, binding.etClassName.text?.toString()?.trim())
                }
                startActivity(intent)
            } else {
                MaterialAlertDialogBuilder(this)
                    .setTitle(R.string.dialog_incomplete_title)
                    .setMessage(R.string.dialog_incomplete_message)
                    .setPositiveButton(R.string.dialog_ok) { dialog, _ -> dialog.dismiss() }
                    .show()
            }
        }
    }

    private fun validateForm(): Boolean {
        val fullName = binding.etFullName.text?.toString()?.trim().orEmpty()
        val email = binding.etEmail.text?.toString()?.trim().orEmpty()
        val phone = binding.etPhone.text?.toString()?.trim()?.replace(" ", "")?.replace("-", "").orEmpty()
        val studentId = binding.etStudentId.text?.toString()?.trim().orEmpty()
        val className = binding.etClassName.text?.toString()?.trim().orEmpty()

        val v1 = when {
            fullName.isEmpty() -> { binding.tilFullName.error = getString(R.string.error_fullname_empty); false }
            fullName.length < 2 -> { binding.tilFullName.error = getString(R.string.error_fullname_short); false }
            else -> { binding.tilFullName.error = null; true }
        }
        val v2 = when {
            email.isEmpty() -> { binding.tilEmail.error = getString(R.string.error_email_empty); false }
            !Patterns.EMAIL_ADDRESS.matcher(email).matches() -> { binding.tilEmail.error = getString(R.string.error_email_invalid); false }
            else -> { binding.tilEmail.error = null; true }
        }
        val v3 = when {
            phone.isEmpty() -> { binding.tilPhone.error = getString(R.string.error_phone_empty); false }
            !Regex("^0[0-9]{9}$").matches(phone) -> { binding.tilPhone.error = getString(R.string.error_phone_invalid) ; false }
            else -> { binding.tilPhone.error = null; true }
        }
        val v4 = when {
            studentId.isEmpty() -> { binding.tilStudentId.error = getString(R.string.error_student_id_empty); false }
            studentId.length < 5 -> { binding.tilStudentId.error = getString(R.string.error_student_id_short); false }
            else -> { binding.tilStudentId.error = null; true }
        }
        val v5 = when {
            className.isEmpty() -> { binding.tilClassName.error = getString(R.string.error_class_name_empty); false }
            else -> { binding.tilClassName.error = null; true }
        }

        return v1 && v2 && v3 && v4 && v5
    }
}